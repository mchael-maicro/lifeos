import { GoogleGenAI } from "@google/genai";
import { plannerPrompt, coachPrompt, analystPrompt, writerPrompt } from "../ai/prompts";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function runAI(mode: string, input: string) {
  let prompt = "";
  switch (mode) {
    case "planner": prompt = plannerPrompt(input); break;
    case "coach": prompt = coachPrompt(input); break;
    case "analyst": prompt = analystPrompt(input); break;
    case "writer": prompt = writerPrompt(input); break;
    default: prompt = plannerPrompt(input);
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });

    if (response.text) {
      return JSON.parse(response.text);
    }
    return null;
  } catch (error) {
    console.error("AI Error:", error);
    throw new Error("Failed to process with AI.");
  }
}
