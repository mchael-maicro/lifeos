import React, { createContext, useContext, useReducer, useEffect } from "react";
import { Task, Note, Goal, Project, AIUsage, UserProfile } from "./types";
import { load, save } from "../services/storageService";

type State = {
  tasks: Task[];
  notes: Note[];
  goals: Goal[];
  projects: Project[];
  usage: AIUsage;
  user: UserProfile;
  isDarkMode: boolean;
  activeProjectId: string | null;
};

const getTodayDate = () => new Date().toISOString().split('T')[0];

const initialState: State = {
  tasks: load('lifeos_tasks') || [],
  notes: load('lifeos_notes') || [],
  goals: load('lifeos_goals') || [
    { id: '1', title: 'Launch MVP', tasks: [], progress: 20 },
    { id: '2', title: 'Get 100 Users', tasks: [], progress: 0 }
  ],
  projects: load('lifeos_projects') || [],
  usage: load('lifeos_usage') || { date: getTodayDate(), count: 0 },
  user: load('lifeos_user') || { id: 'user_1', tier: 'free' },
  isDarkMode: load('lifeos_theme') ?? true,
  activeProjectId: null,
};

type Action = 
  | { type: "ADD_TASKS"; payload: Task[] }
  | { type: "UPDATE_TASK"; payload: Task }
  | { type: "TOGGLE_TASK"; payload: string }
  | { type: "ADD_PROJECT"; payload: Project }
  | { type: "SET_ACTIVE_PROJECT"; payload: string | null }
  | { type: "INCREMENT_USAGE" }
  | { type: "TOGGLE_THEME" }
  | { type: "UPGRADE_PRO" }
  | { type: "UPGRADE_TIER"; payload: 'free' | 'pro' | 'team' | 'enterprise' };

function reducer(state: State, action: Action): State {
  let newState = state;
  switch (action.type) {
    case "ADD_TASKS":
      newState = { ...state, tasks: [...action.payload, ...state.tasks] };
      break;
    case "UPDATE_TASK":
      newState = {
        ...state,
        tasks: state.tasks.map(t => t.id === action.payload.id ? action.payload : t)
      };
      break;
    case "TOGGLE_TASK":
      newState = {
        ...state,
        tasks: state.tasks.map(t => t.id === action.payload ? { ...t, completed: !t.completed } : t)
      };
      break;
    case "ADD_PROJECT":
      newState = { ...state, projects: [...state.projects, action.payload] };
      break;
    case "SET_ACTIVE_PROJECT":
      newState = { ...state, activeProjectId: action.payload };
      break;
    case "INCREMENT_USAGE":
      const today = getTodayDate();
      if (state.usage.date !== today) {
        newState = { ...state, usage: { date: today, count: 1 } };
      } else {
        newState = { ...state, usage: { ...state.usage, count: state.usage.count + 1 } };
      }
      break;
    case "TOGGLE_THEME":
      newState = { ...state, isDarkMode: !state.isDarkMode };
      break;
    case "UPGRADE_PRO":
      newState = { ...state, user: { ...state.user, tier: 'pro' } };
      break;
    case "UPGRADE_TIER":
      newState = { ...state, user: { ...state.user, tier: action.payload } };
      break;
    default:
      return state;
  }
  
  save('lifeos_tasks', newState.tasks);
  save('lifeos_notes', newState.notes);
  save('lifeos_goals', newState.goals);
  save('lifeos_projects', newState.projects);
  save('lifeos_usage', newState.usage);
  save('lifeos_user', newState.user);
  save('lifeos_theme', newState.isDarkMode);

  return newState;
}

const AppContext = createContext<{ state: State; dispatch: React.Dispatch<Action> } | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  useEffect(() => {
    if (state.isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [state.isDarkMode]);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
}

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error("useApp must be used within AppProvider");
  return context;
};
