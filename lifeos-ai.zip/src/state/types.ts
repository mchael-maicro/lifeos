export type Task = {
  id: string;
  title: string;
  completed: boolean;
  priority?: "low" | "medium" | "high";
  projectId?: string;
  dueDate?: string;
  createdAt: number;
};

export type Note = {
  id: string;
  content: string;
  createdAt: number;
};

export type Goal = {
  id: string;
  title: string;
  tasks: string[]; // task IDs
  progress: number;
};

export type Project = {
  id: string;
  name: string;
  taskIds: string[];
};

export type AIUsage = {
  date: string;
  count: number;
};

export type UserProfile = {
  id: string;
  tier: 'free' | 'pro' | 'team' | 'enterprise';
};
