import React from "react";
import { CheckCircle2, Target, BrainCircuit, FileText } from "lucide-react";

export const AI_MODES = [
  { id: 'planner', name: 'Planner', icon: <CheckCircle2 size={16} /> },
  { id: 'coach', name: 'Coach', icon: <Target size={16} /> },
  { id: 'analyst', name: 'Analyst', icon: <BrainCircuit size={16} /> },
  { id: 'writer', name: 'Writer', icon: <FileText size={16} /> }
];

export default function AIModeSelector({ mode, setMode }: { mode: string, setMode: (m: string) => void }) {
  return (
    <div className="flex flex-wrap gap-2">
      {AI_MODES.map((m) => (
        <button
          key={m.id}
          onClick={() => setMode(m.id)}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all ${
            mode === m.id 
              ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/20" 
              : "bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-300 dark:hover:bg-slate-700"
          }`}
        >
          {m.icon}
          {m.name}
        </button>
      ))}
    </div>
  );
}
