import React, { useState } from 'react';
import ActionButton from './ActionButton';

export function TeamView() {
  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-black tracking-tight mb-2">TeamHub</h1>
          <p className="text-slate-500 dark:text-slate-400 font-medium">Manage your employees, attendance, and recruitment.</p>
        </div>
        <ActionButton 
          className="px-4 py-2 bg-[#4A90E2] text-white font-bold rounded-xl hover:bg-blue-600 transition-colors shadow-lg shadow-blue-500/20 whitespace-nowrap"
          successText="Added!"
          loadingText="Adding..."
        >
          + Add Employee
        </ActionButton>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800 border-l-4 border-l-[#8BC34A]">
          <h3 className="text-slate-800 dark:text-white text-3xl font-black mb-1">128</h3>
          <p className="text-slate-500 text-sm font-medium">Total Employees</p>
        </div>
        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800 border-l-4 border-l-[#4A90E2]">
          <h3 className="text-slate-800 dark:text-white text-3xl font-black mb-1">92%</h3>
          <p className="text-slate-500 text-sm font-medium">Attendance Rate</p>
        </div>
        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800 border-l-4 border-l-[#FF9800]">
          <h3 className="text-slate-800 dark:text-white text-3xl font-black mb-1">89.5%</h3>
          <p className="text-slate-500 text-sm font-medium">Team Performance</p>
        </div>
      </div>
      <h3 className="text-xl font-black mb-4">Recruitment Pipeline</h3>
      <div className="space-y-4">
        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div>
            <h4 className="font-bold text-lg mb-1">Product Designer Candidate</h4>
            <p className="text-sm text-slate-500 font-medium">Interview scheduled • 10:00 AM</p>
          </div>
          <div className="px-3 py-1 bg-blue-100 dark:bg-blue-500/20 text-[#4A90E2] text-xs font-bold rounded-full">
            In Progress
          </div>
        </div>
      </div>
    </div>
  );
}

export function CRMView() {
  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-black tracking-tight mb-2">AIZCRM</h1>
          <p className="text-slate-500 dark:text-slate-400 font-medium">Track sales, revenue, and market share.</p>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
        <div className="md:col-span-2 bg-gradient-to-br from-slate-900 to-slate-800 p-8 rounded-3xl shadow-sm border border-slate-800">
          <h3 className="text-slate-400 text-sm font-medium mb-2">Total Sales</h3>
          <h2 className="text-white text-5xl font-black mb-6">1,200K</h2>
          <div className="w-full h-3 bg-slate-800 rounded-full overflow-hidden">
            <div className="h-full bg-[#4A90E2] rounded-full" style={{ width: '70%' }}></div>
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800">
          <h3 className="text-slate-500 dark:text-slate-400 text-sm font-medium mb-6">Market Share</h3>
          <div className="mb-4">
            <div className="flex justify-between text-sm font-bold mb-2">
              <span className="text-slate-800 dark:text-white">TikTok</span>
              <span className="text-slate-500">25%</span>
            </div>
            <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
              <div className="h-full bg-slate-800 dark:bg-white rounded-full" style={{ width: '25%' }}></div>
            </div>
          </div>
          <div>
            <div className="flex justify-between text-sm font-bold mb-2">
              <span className="text-[#8BC34A]">Instagram</span>
              <span className="text-[#8BC34A]">50%</span>
            </div>
            <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
              <div className="h-full bg-[#8BC34A] rounded-full" style={{ width: '50%' }}></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function EcommerceView() {
  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-black tracking-tight mb-2">My Storehouse</h1>
          <p className="text-slate-500 dark:text-slate-400 font-medium">Manage products and inventory.</p>
        </div>
        <ActionButton 
          className="px-4 py-2 bg-[#FF9800] text-white font-bold rounded-xl hover:bg-orange-600 transition-colors shadow-lg shadow-orange-500/20 whitespace-nowrap flex items-center gap-2"
          successText="Scanned!"
          loadingText="Scanning..."
        >
          <span>📷</span> Scan Barcode
        </ActionButton>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800">
          <div className="h-32 bg-slate-100 dark:bg-slate-800 rounded-2xl mb-4 flex items-center justify-center text-5xl">🛋️</div>
          <h3 className="text-xl font-black mb-1">Blob Sofa</h3>
          <p className="text-slate-500 text-sm font-medium">Stock: 25 units • In Warehouse</p>
        </div>
        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800">
          <div className="h-32 bg-slate-100 dark:bg-slate-800 rounded-2xl mb-4 flex items-center justify-center text-5xl">🪴</div>
          <h3 className="text-xl font-black mb-1">Copse Combo</h3>
          <p className="text-slate-500 text-sm font-medium">Stock: 100 units • Low Stock</p>
        </div>
      </div>
    </div>
  );
}

export function ChatView() {
  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-black tracking-tight mb-2">Messages</h1>
          <p className="text-slate-500 dark:text-slate-400 font-medium">Communicate with your team and clients.</p>
        </div>
      </div>
      <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800 min-h-[500px] flex flex-col">
        <div className="flex-1 p-6 overflow-y-auto space-y-6">
          <div className="flex gap-3">
            <div className="w-10 h-10 rounded-full bg-slate-200 dark:bg-slate-800 flex items-center justify-center font-bold text-sm shrink-0">JM</div>
            <div>
              <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded-2xl rounded-tl-none text-slate-800 dark:text-slate-200">
                <p>Hi, I just received my delivery but it seems my order is missing an item.</p>
              </div>
              <span className="text-xs text-slate-500 mt-1 block">Joe Martin • 7:00 PM</span>
            </div>
          </div>
          <div className="flex gap-3 flex-row-reverse">
            <div className="w-10 h-10 rounded-full bg-[#8BC34A] text-white flex items-center justify-center font-bold text-sm shrink-0">Me</div>
            <div className="flex flex-col items-end">
              <div className="bg-[#4A90E2] text-white p-4 rounded-2xl rounded-tr-none">
                <p>Oh no, we're sorry about that! Let us know what's missing so we can make it right.</p>
              </div>
              <span className="text-xs text-slate-500 mt-1 block">7:01 PM</span>
            </div>
          </div>
        </div>
        <div className="p-4 border-t border-slate-100 dark:border-slate-800">
          <input type="text" className="w-full bg-slate-100 dark:bg-slate-800 border-none rounded-xl px-4 py-3 text-slate-800 dark:text-white focus:ring-2 focus:ring-[#4A90E2] outline-none" placeholder="Type a message..." />
        </div>
      </div>
    </div>
  );
}

export function TravelView() {
  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-black tracking-tight mb-2">Travel & Logistics</h1>
          <p className="text-slate-500 dark:text-slate-400 font-medium">Book trips and track live rides.</p>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800 border-t-4 border-t-[#4A90E2] flex flex-col">
          <h3 className="text-xl font-black mb-2">✈️ Travelzo</h3>
          <p className="text-slate-500 text-sm font-medium mb-4">Destination: Moon (22-31 July)</p>
          <h2 className="text-4xl font-black text-slate-800 dark:text-white mb-6">$12,999</h2>
          <ActionButton 
            className="mt-auto w-full py-3 bg-[#4A90E2] text-white font-bold rounded-xl hover:bg-blue-600 transition-colors"
            successText="Booked!"
            loadingText="Processing..."
          >
            Pay & Fly
          </ActionButton>
        </div>
        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800 border-t-4 border-t-[#FF9800] flex flex-col">
          <h3 className="text-xl font-black mb-4">🚕 Taxio Live Tracking</h3>
          <div className="h-32 bg-slate-100 dark:bg-slate-800 rounded-2xl mb-4 flex items-center justify-center text-slate-500 font-medium">
            [Live GPS Map View]
          </div>
          <p className="text-slate-500 text-sm font-medium">Driver arriving in 3 mins.</p>
        </div>
      </div>
    </div>
  );
}

export function CryptoView() {
  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-black tracking-tight mb-2">Trading Portfolio</h1>
          <p className="text-slate-500 dark:text-slate-400 font-medium">Track your assets in real-time.</p>
        </div>
      </div>
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h3 className="text-slate-500 font-medium mb-1">Main Portfolio</h3>
            <h1 className="text-4xl font-black text-[#8BC34A]">14.71% 📈</h1>
          </div>
          <div className="text-right">
            <p className="text-slate-500 text-sm font-medium mb-1">30MA Trend</p>
            <h3 className="text-2xl font-black text-slate-800 dark:text-white">$110.22</h3>
          </div>
        </div>
        <div className="h-40 bg-gradient-to-b from-[#8BC34A]/20 to-transparent border-b-2 border-[#8BC34A] rounded-xl"></div>
      </div>
    </div>
  );
}

export function CalendarView() {
  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-black tracking-tight mb-2">Calendar & Timeline</h1>
          <p className="text-slate-500 dark:text-slate-400 font-medium">Track overlapping projects and daily meetings.</p>
        </div>
        <ActionButton 
          className="px-4 py-2 bg-[#4A90E2] text-white font-bold rounded-xl hover:bg-blue-600 transition-colors shadow-lg shadow-blue-500/20 whitespace-nowrap"
          successText="Scheduled!"
          loadingText="Scheduling..."
        >
          + Schedule
        </ActionButton>
      </div>

      <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800 mb-10">
        <h3 className="text-xl font-black mb-6">Q3 Project Timeline</h3>
        
        <div className="space-y-4">
          <div className="flex items-center">
            <div className="w-32 text-sm text-slate-500 font-medium">Project kickoff</div>
            <div className="flex-1 bg-slate-100 dark:bg-slate-800 h-8 rounded-full relative overflow-hidden">
              <div className="absolute h-full bg-[#E74C3C] rounded-full flex items-center px-3 text-xs font-bold text-white" style={{ width: '40%', left: '0%' }}>Mon - Wed</div>
            </div>
          </div>
          <div className="flex items-center">
            <div className="w-32 text-sm text-slate-500 font-medium">Interviews</div>
            <div className="flex-1 bg-slate-100 dark:bg-slate-800 h-8 rounded-full relative overflow-hidden">
              <div className="absolute h-full bg-[#4A90E2] rounded-full flex items-center px-3 text-xs font-bold text-white" style={{ width: '30%', left: '30%' }}>Wed - Fri</div>
            </div>
          </div>
          <div className="flex items-center">
            <div className="w-32 text-sm text-slate-500 font-medium">Analyse</div>
            <div className="flex-1 bg-slate-100 dark:bg-slate-800 h-8 rounded-full relative overflow-hidden">
              <div className="absolute h-full bg-[#8BC34A] rounded-full flex items-center px-3 text-xs font-bold text-white" style={{ width: '50%', left: '50%' }}>Fri - Sun</div>
            </div>
          </div>
        </div>
      </div>

      <h3 className="text-xl font-black mb-4">Today's Agenda</h3>
      <div className="space-y-4">
        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800 border-l-4 border-l-[#FF9800] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h4 className="text-[#FF9800] font-bold mb-1">08:00 - 10:00 AM</h4>
            <p className="font-black text-lg text-slate-800 dark:text-white mb-1">Meeting with pela members</p>
            <p className="text-sm text-slate-500 font-medium">Participants: Design team • 5 People</p>
          </div>
          <ActionButton 
            className="px-4 py-2 border border-[#FF9800] text-[#FF9800] font-bold rounded-xl hover:bg-orange-50 dark:hover:bg-orange-900/20 transition-colors whitespace-nowrap"
            successText="Joined!"
            loadingText="Connecting..."
          >
            Join Video
          </ActionButton>
        </div>
      </div>
    </div>
  );
}

export function IntegrationsView() {
  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-black tracking-tight mb-2">Integrations</h1>
          <p className="text-slate-500 dark:text-slate-400 font-medium">Connect LifeOS to your external tools.</p>
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800 flex items-center gap-4">
          <div className="text-4xl">💬</div>
          <div>
            <h3 className="text-xl font-black mb-1">Slack</h3>
            <p className="text-[#8BC34A] text-sm font-bold">Connected</p>
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800 flex items-center gap-4">
          <div className="text-4xl">📓</div>
          <div>
            <h3 className="text-xl font-black mb-1">Notion</h3>
            <p className="text-[#8BC34A] text-sm font-bold">Connected</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export function StudioView() {
  const [isPlaying, setIsPlaying] = useState(true);
  const [isInstrumental, setIsInstrumental] = useState(false);
  const [isAutoLyrics, setIsAutoLyrics] = useState(false);

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-black tracking-tight mb-2">Audio Studio</h1>
          <p className="text-slate-500 dark:text-slate-400 font-medium">Sound Aloft mixing and Gemini AI music generation.</p>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800 border-l-4 border-l-[#4A90E2] mb-10">
        <h3 className="text-xl font-black mb-2 flex items-center gap-2">
          <span className="text-2xl">✨</span> Gemini Track Generator (Lyria 3)
        </h3>
        <p className="text-slate-500 text-sm font-medium mb-6">Generate professional-grade 30-second tracks with vocals.</p>
        
        <div className="flex flex-col sm:flex-row gap-4 mb-4">
          <input type="text" className="flex-1 bg-slate-100 dark:bg-slate-800 border-none rounded-xl px-4 py-3 text-slate-800 dark:text-white focus:ring-2 focus:ring-[#4A90E2] outline-none" placeholder="e.g., An upbeat house music track with a heavy driving bassline..." />
          <ActionButton 
            className="px-8 py-3 bg-[#4A90E2] text-white font-bold rounded-full hover:bg-blue-600 transition-colors shadow-lg shadow-blue-500/20 whitespace-nowrap"
            successText="Generated!"
            loadingText="Generating..."
          >
            Generate
          </ActionButton>
        </div>
        
        <div className="flex gap-3">
          <button 
            onClick={() => setIsInstrumental(!isInstrumental)}
            className={`px-3 py-1 text-xs font-bold rounded-full border transition-colors ${isInstrumental ? 'bg-[#4A90E2] text-white border-[#4A90E2]' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700'}`}
          >
            Instrumental Only
          </button>
          <button 
            onClick={() => setIsAutoLyrics(!isAutoLyrics)}
            className={`px-3 py-1 text-xs font-bold rounded-full border transition-colors ${isAutoLyrics ? 'bg-[#4A90E2] text-white border-[#4A90E2]' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700'}`}
          >
            Auto-Lyrics
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Radar UI / SOUND ALDOFT */}
        <div className="lg:col-span-1 bg-[#1A1325] p-8 rounded-3xl shadow-sm border border-[#D4AF37]/20 flex flex-col items-center justify-center relative overflow-hidden">
          <div className="absolute top-6 left-6">
            <h3 className="text-[#D4AF37] font-bold tracking-[0.2em] text-sm">SOUND ALDOFT</h3>
          </div>
          
          {/* Radar Animation */}
          <div className="w-48 h-48 rounded-full border border-[#D4AF37]/30 flex items-center justify-center relative mt-8">
            <div className="absolute inset-0 rounded-full border border-[#D4AF37]/20 m-4"></div>
            <div className="absolute inset-0 rounded-full border border-[#D4AF37]/10 m-8"></div>
            <div className="absolute w-1/2 h-[1px] bg-gradient-to-r from-transparent to-[#D4AF37] origin-left animate-[spin_4s_linear_infinite] left-1/2 top-1/2"></div>
            <div className="z-10 text-[#D4AF37] font-mono text-xs tracking-widest bg-[#1A1325] px-2">RADAR</div>
            
            {/* Radar blips */}
            <div className="absolute w-2 h-2 bg-[#D4AF37] rounded-full top-10 left-12 shadow-[0_0_8px_#D4AF37] animate-pulse"></div>
            <div className="absolute w-1.5 h-1.5 bg-[#D4AF37] rounded-full bottom-14 right-10 shadow-[0_0_8px_#D4AF37] animate-pulse" style={{ animationDelay: '1s' }}></div>
          </div>

          {/* Mixing Sliders */}
          <div className="w-full mt-12 flex justify-between px-4">
            {['BASS', 'MID', 'TREB', 'VOL'].map((label, i) => (
              <div key={label} className="flex flex-col items-center gap-3">
                <div className="h-24 w-1.5 bg-slate-800 rounded-full relative flex justify-center">
                  <div 
                    className="absolute bottom-0 w-full bg-gradient-to-t from-[#D4AF37]/50 to-[#D4AF37] rounded-full" 
                    style={{ height: `${[60, 40, 75, 90][i]}%` }}
                  ></div>
                  <div 
                    className="w-4 h-4 bg-white rounded-full shadow-md absolute -translate-x-1/2 cursor-pointer hover:scale-110 transition-transform"
                    style={{ bottom: `calc(${[60, 40, 75, 90][i]}% - 8px)`, left: '50%' }}
                  ></div>
                </div>
                <span className="text-[10px] text-slate-400 font-mono tracking-wider">{label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Studio Pley Media Player */}
        <div className="lg:col-span-2 bg-gradient-to-br from-[#1A1325] to-[#2A1F3D] p-10 rounded-3xl shadow-sm border border-[#D4AF37]/20 flex flex-col items-center justify-center relative">
          <div className="absolute top-6 left-6">
            <h3 className="text-[#D4AF37] font-bold tracking-[0.2em] text-sm">STUDIO PLEY</h3>
          </div>

          <div className={`w-40 h-40 rounded-full border-2 border-dashed border-[#D4AF37]/50 flex items-center justify-center relative mb-8 mt-4 ${isPlaying ? 'animate-[spin_20s_linear_infinite]' : ''}`}>
            <div className={`w-32 h-32 rounded-full bg-[#D4AF37]/10 border border-[#D4AF37] flex items-center justify-center ${isPlaying ? 'animate-[spin_20s_linear_infinite_reverse]' : ''}`}>
              <span className="text-5xl">🎧</span>
            </div>
          </div>
          
          <h2 className="text-white text-3xl font-black mb-2 tracking-tight">House Mix Vol. 1</h2>
          <p className="text-[#D4AF37] text-sm font-medium mb-8 tracking-widest uppercase">{isPlaying ? 'Playing on all LifeOS tabs' : 'Paused'}</p>
          
          {/* Progress Bar */}
          <div className="w-full max-w-md h-1.5 bg-slate-800 rounded-full relative mb-6 cursor-pointer">
            <div className="absolute left-0 top-0 h-full w-[45%] bg-[#D4AF37] rounded-full shadow-[0_0_10px_rgba(212,175,55,0.5)]"></div>
            <div className="absolute left-[45%] top-1/2 -translate-y-1/2 w-4 h-4 bg-white rounded-full shadow-md hover:scale-125 transition-transform"></div>
          </div>
          <div className="w-full max-w-md flex justify-between text-xs font-bold text-slate-400 mb-8 font-mono">
            <span>02:14</span>
            <span>05:40</span>
          </div>

          {/* Controls */}
          <div className="flex items-center gap-8">
            <button className="text-slate-400 hover:text-white transition-colors text-xl">🔀</button>
            <button className="text-slate-300 hover:text-white transition-colors text-2xl hover:scale-110 transform">⏮</button>
            <button 
              onClick={() => setIsPlaying(!isPlaying)}
              className="w-16 h-16 rounded-full bg-[#D4AF37] text-[#1A1325] flex items-center justify-center text-2xl hover:scale-105 transition-transform shadow-[0_0_20px_rgba(212,175,55,0.4)]"
            >
              {isPlaying ? '⏸' : '▶'}
            </button>
            <button className="text-slate-300 hover:text-white transition-colors text-2xl hover:scale-110 transform">⏭</button>
            <button className="text-slate-400 hover:text-white transition-colors text-xl">🔁</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export function AIStudioView() {
  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-black tracking-tight mb-2">AI Studio</h1>
          <p className="text-slate-500 dark:text-slate-400 font-medium">Powerful AI tools grouped into step-by-step workflows.</p>
        </div>
        <ActionButton 
          className="px-4 py-2 bg-[#4A90E2] text-white font-bold rounded-xl hover:bg-blue-600 transition-colors shadow-lg shadow-blue-500/20 whitespace-nowrap"
          successText="Ready!"
          loadingText="Building..."
        >
          + Build Custom Workflow
        </ActionButton>
      </div>

      <h3 className="text-xl font-black mb-2">Content Creator Suite</h3>
      <p className="text-slate-500 dark:text-slate-400 text-sm font-medium mb-6">Go from a blank page to a published masterpiece.</p>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800 border-t-4 border-t-[#4A90E2] flex flex-col">
          <div className="px-3 py-1 bg-blue-100 dark:bg-blue-500/20 text-[#4A90E2] text-xs font-bold rounded-full w-fit mb-4">Step 1: Scratch</div>
          <h3 className="text-lg font-black mb-2">💡 Ideation Engine</h3>
          <p className="text-slate-500 text-sm font-medium mb-6">Generate viral hooks, vlog concepts, and video titles.</p>
          <ActionButton 
            className="mt-auto w-full py-2 border border-[#4A90E2] text-[#4A90E2] font-bold rounded-xl hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors"
            successText="Launched!"
            loadingText="Launching..."
          >
            Launch Tool
          </ActionButton>
        </div>

        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800 border-t-4 border-t-[#FF9800] flex flex-col">
          <div className="px-3 py-1 bg-amber-100 dark:bg-amber-500/20 text-[#FF9800] text-xs font-bold rounded-full w-fit mb-4">Step 2: Build</div>
          <h3 className="text-lg font-black mb-2">✍️ Script & Copywriter</h3>
          <p className="text-slate-500 text-sm font-medium mb-6">Turn your rough ideas into full video scripts and social posts.</p>
          <ActionButton 
            className="mt-auto w-full py-2 border border-[#FF9800] text-[#FF9800] font-bold rounded-xl hover:bg-orange-50 dark:hover:bg-orange-900/20 transition-colors"
            successText="Launched!"
            loadingText="Launching..."
          >
            Launch Tool
          </ActionButton>
        </div>

        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800 border-t-4 border-t-[#8BC34A] flex flex-col">
          <div className="px-3 py-1 bg-green-100 dark:bg-green-500/20 text-[#8BC34A] text-xs font-bold rounded-full w-fit mb-4">Step 3: Enhance</div>
          <h3 className="text-lg font-black mb-2">🎨 Media Generator</h3>
          <p className="text-slate-500 text-sm font-medium mb-6">Create AI images, background music, and video assets.</p>
          <ActionButton 
            className="mt-auto w-full py-2 border border-[#8BC34A] text-[#8BC34A] font-bold rounded-xl hover:bg-green-50 dark:hover:bg-green-900/20 transition-colors"
            successText="Launched!"
            loadingText="Launching..."
          >
            Launch Tool
          </ActionButton>
        </div>
        
        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800 border-t-4 border-t-[#E74C3C] flex flex-col">
          <div className="px-3 py-1 bg-rose-100 dark:bg-rose-500/20 text-[#E74C3C] text-xs font-bold rounded-full w-fit mb-4">Step 4: Advanced</div>
          <h3 className="text-lg font-black mb-2">🚀 SEO & Publishing</h3>
          <p className="text-slate-500 text-sm font-medium mb-6">Auto-generate hashtags, meta descriptions, and schedule.</p>
          <ActionButton 
            className="mt-auto w-full py-2 border border-[#E74C3C] text-[#E74C3C] font-bold rounded-xl hover:bg-rose-50 dark:hover:bg-rose-900/20 transition-colors"
            successText="Launched!"
            loadingText="Launching..."
          >
            Launch Tool
          </ActionButton>
        </div>
      </div>

      <h3 className="text-xl font-black mb-2 mt-8">Gemini Media Creation</h3>
      <p className="text-slate-500 dark:text-slate-400 text-sm font-medium mb-6">Powered by state-of-the-art native models.</p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800 border-t-4 border-t-[#FF9800] flex flex-col">
          <h3 className="text-xl font-black mb-2 flex items-center gap-2">
            <span className="text-2xl">🖼️</span> Image Studio
          </h3>
          <p className="text-slate-500 text-sm font-medium mb-6">Powered by Nano Banana. Generate and edit high-fidelity images.</p>
          <input type="text" className="w-full bg-slate-100 dark:bg-slate-800 border-none rounded-xl px-4 py-3 text-slate-800 dark:text-white focus:ring-2 focus:ring-[#FF9800] outline-none mb-4" placeholder="Describe an image..." />
          <ActionButton 
            className="w-full py-3 bg-[#FF9800] text-white font-bold rounded-xl hover:bg-orange-600 transition-colors"
            successText="Generated!"
            loadingText="Generating..."
          >
            Generate Image
          </ActionButton>
          <p className="text-slate-400 text-xs font-medium mt-3 text-center">1000 uses per day quota</p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800 border-t-4 border-t-[#E74C3C] flex flex-col">
          <h3 className="text-xl font-black mb-2 flex items-center gap-2">
            <span className="text-2xl">🎥</span> Video Studio
          </h3>
          <p className="text-slate-500 text-sm font-medium mb-6">Powered by Veo. Text-to-video with natively generated audio.</p>
          <input type="text" className="w-full bg-slate-100 dark:bg-slate-800 border-none rounded-xl px-4 py-3 text-slate-800 dark:text-white focus:ring-2 focus:ring-[#E74C3C] outline-none mb-4" placeholder="Describe a video scene..." />
          <ActionButton 
            className="w-full py-3 bg-[#E74C3C] text-white font-bold rounded-xl hover:bg-rose-600 transition-colors"
            successText="Generated!"
            loadingText="Generating..."
          >
            Generate Video
          </ActionButton>
          <p className="text-slate-400 text-xs font-medium mt-3 text-center">3 uses per day quota</p>
        </div>
      </div>
    </div>
  );
}
