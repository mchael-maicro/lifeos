import React from 'react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: any) => void;
}

export default function Sidebar({ activeTab, setActiveTab }: SidebarProps) {
  const NavItem = ({ id, icon, label }: { id: string, icon: string, label: string }) => (
    <button
      onClick={() => setActiveTab(id)}
      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-bold text-sm transition-all ${
        activeTab === id 
          ? 'bg-[#4A90E2] text-white shadow-md shadow-blue-500/20' 
          : 'text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-200/50 dark:hover:bg-slate-800/50'
      }`}
    >
      <span className="text-lg">{icon}</span>
      {label}
    </button>
  );

  const NavCategory = ({ children }: { children: React.ReactNode }) => (
    <div className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mt-6 mb-2 px-4">
      {children}
    </div>
  );

  return (
    <div className="w-72 h-screen fixed left-0 top-0 bg-slate-50 dark:bg-slate-900/50 border-r border-slate-200 dark:border-slate-800 flex flex-col hidden lg:flex z-40">
      <div className="p-6">
        <div className="text-2xl font-black text-[#4A90E2] tracking-wide">LifeOS AI</div>
      </div>
      
      <div className="flex-1 overflow-y-auto scrollbar-hide px-4 pb-24">
        <NavCategory>Core System</NavCategory>
        <NavItem id="dashboard" icon="🏠" label="Dashboard" />
        <NavItem id="tasks" icon="✅" label="Tasks & Priorities" />
        <NavItem id="projects" icon="🎯" label="Projects & Goals" />
        <NavItem id="calendar" icon="📅" label="Calendar & Timeline" />
        <NavItem id="habits" icon="🔥" label="Habits & Routines" />
        <NavItem id="focus" icon="⏳" label="Deep Focus" />

        <NavCategory>Life & Wealth</NavCategory>
        <NavItem id="finance" icon="💳" label="Wallet & Finances" />
        <NavItem id="crypto" icon="📊" label="Trading Portfolio" />
        <NavItem id="health" icon="❤️" label="Health & Vitals" />
        <NavItem id="elearning" icon="📚" label="E-Learning Hub" />

        <NavCategory>AI & Workspace</NavCategory>
        <NavItem id="aistudio" icon="✨" label="AI Studio" />
        <NavItem id="ai-chat" icon="💬" label="AI Chat Sync" />
        <NavItem id="studio" icon="🎧" label="Audio Studio" />
        <NavItem id="spaces" icon="🌌" label="Smart Spaces" />
        <NavItem id="flows" icon="⚙️" label="Logic Flows" />
        <NavItem id="files" icon="📁" label="File Vault" />

        <NavCategory>Pro Business</NavCategory>
        <NavItem id="team" icon="👥" label="TeamHub (HR)" />
        <NavItem id="crm" icon="📈" label="AIZCRM (Sales)" />
        <NavItem id="ecommerce" icon="📦" label="E-Commerce" />
        <NavItem id="chat" icon="💬" label="Messages" />
        <NavItem id="travel" icon="✈️" label="Travel & Rides" />

        <NavCategory>System</NavCategory>
        <NavItem id="integrations" icon="🔗" label="Integrations" />
        <NavItem id="ai-suggestions" icon="🤖" label="Proactive AI" />
        <NavItem id="applock" icon="🔒" label="Privacy & AppLock" />
        <NavItem id="settings" icon="⚙️" label="Settings" />
      </div>
    </div>
  );
}
