import React, { useState } from 'react';

interface ActionButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  successText?: string;
  loadingText?: string;
  icon?: React.ReactNode;
}

export default function ActionButton({ 
  children, 
  onClick, 
  className, 
  successText = "Done!", 
  loadingText = "Processing...",
  icon,
  ...props 
}: ActionButtonProps) {
  const [status, setStatus] = useState<'idle' | 'loading' | 'success'>('idle');

  const handleClick = async (e: React.MouseEvent<HTMLButtonElement>) => {
    if (status !== 'idle') return;
    setStatus('loading');
    
    try {
      if (onClick) {
        await onClick(e);
      } else {
        // Default simulated delay if no onClick is provided
        await new Promise(r => setTimeout(r, 800));
      }
      setStatus('success');
    } catch (error) {
      setStatus('idle');
    }
    
    setTimeout(() => {
      setStatus('idle');
    }, 2000);
  };

  return (
    <button 
      onClick={handleClick}
      className={`${className} transition-all relative overflow-hidden`}
      disabled={status === 'loading'}
      {...props}
    >
      <span className={`flex items-center justify-center gap-2 transition-opacity ${status !== 'idle' ? 'opacity-0' : 'opacity-100'}`}>
        {icon && <span>{icon}</span>}
        {children}
      </span>
      {status === 'loading' && (
        <span className="absolute inset-0 flex items-center justify-center gap-2 font-bold animate-pulse">
          <span className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin"></span>
          {loadingText}
        </span>
      )}
      {status === 'success' && (
        <span className="absolute inset-0 flex items-center justify-center font-bold">
          {successText}
        </span>
      )}
    </button>
  );
}
