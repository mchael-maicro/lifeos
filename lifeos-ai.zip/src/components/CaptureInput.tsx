import React, { useState } from "react";
import { ArrowRight } from "lucide-react";

export default function CaptureInput({ onSubmit, isThinking }: { onSubmit: (text: string) => void, isThinking?: boolean }) {
  const [text, setText] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (text.trim() && !isThinking) {
      onSubmit(text);
      setText("");
    }
  };

  return (
    <form onSubmit={handleSubmit} className="relative w-full">
      <input
        type="text"
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="What's on your mind today? Type a thought, idea, or task..."
        className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-full py-4 pl-6 pr-16 shadow-lg shadow-slate-200/50 dark:shadow-none focus:outline-none focus:ring-2 focus:ring-[#4A90E2]/50 transition-all text-lg"
        disabled={isThinking}
      />
      <button
        type="submit"
        disabled={!text.trim() || isThinking}
        className="absolute right-2 top-1/2 -translate-y-1/2 p-2.5 bg-[#4A90E2] text-white rounded-full hover:bg-blue-600 transition-colors disabled:opacity-50"
      >
        <ArrowRight size={20} />
      </button>
    </form>
  );
}
