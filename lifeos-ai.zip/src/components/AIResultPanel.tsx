import React from "react";
import { X, Check } from "lucide-react";

export default function AIResultPanel({ 
  result, 
  mode, 
  onAccept, 
  onDiscard 
}: { 
  result: any, 
  mode: string, 
  onAccept: () => void, 
  onDiscard: () => void 
}) {
  
  const renderContent = () => {
    if (mode === 'planner' && result.tasks) {
      return (
        <ul className="space-y-2">
          {result.tasks.map((t: any, i: number) => (
            <li key={i} className="flex items-center gap-3 p-3 bg-white/5 dark:bg-black/20 rounded-xl border border-slate-200 dark:border-slate-800">
              <div className="w-4 h-4 rounded border border-slate-400"></div>
              <span className="flex-1 font-medium">{t.title}</span>
              {t.priority && (
                <span className={`text-[10px] font-bold uppercase px-2 py-1 rounded ${
                  t.priority === 'high' ? 'bg-rose-500/10 text-rose-500' :
                  t.priority === 'medium' ? 'bg-amber-500/10 text-amber-500' :
                  'bg-emerald-500/10 text-emerald-500'
                }`}>
                  {t.priority}
                </span>
              )}
            </li>
          ))}
        </ul>
      );
    }
    if (mode === 'coach') {
      return (
        <div className="space-y-4">
          <p className="text-lg italic text-slate-600 dark:text-slate-300">"{result.reflection}"</p>
          <div className="p-4 bg-indigo-500/10 border border-indigo-500/20 rounded-xl">
            <h4 className="text-xs font-bold uppercase text-indigo-500 mb-1">Next Action</h4>
            <p className="font-medium text-indigo-900 dark:text-indigo-100">{result.action}</p>
          </div>
        </div>
      );
    }
    if (mode === 'analyst') {
      return (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {result.options?.map((opt: any, i: number) => (
              <div key={i} className="p-4 bg-white/5 dark:bg-black/20 rounded-xl border border-slate-200 dark:border-slate-800">
                <h4 className="font-bold mb-2">{opt.name}</h4>
                <div className="space-y-2 text-sm">
                  <div>
                    <span className="text-emerald-500 font-bold">Pros:</span>
                    <ul className="list-disc pl-4 text-slate-600 dark:text-slate-400">
                      {opt.pros?.map((p: string, j: number) => <li key={j}>{p}</li>)}
                    </ul>
                  </div>
                  <div>
                    <span className="text-rose-500 font-bold">Cons:</span>
                    <ul className="list-disc pl-4 text-slate-600 dark:text-slate-400">
                      {opt.cons?.map((c: string, j: number) => <li key={j}>{c}</li>)}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="p-4 bg-indigo-500/10 border border-indigo-500/20 rounded-xl">
            <h4 className="text-xs font-bold uppercase text-indigo-500 mb-1">Recommendation</h4>
            <p className="font-medium text-indigo-900 dark:text-indigo-100">{result.recommendation}</p>
          </div>
        </div>
      );
    }
    if (mode === 'writer') {
      return (
        <div className="space-y-4">
          <div className="p-4 bg-white/5 dark:bg-black/20 rounded-xl border border-slate-200 dark:border-slate-800">
            <p className="font-medium">{result.rewritten}</p>
          </div>
          <div className="text-sm text-slate-600 dark:text-slate-400">
            <p className="font-bold mb-1">Summary:</p>
            <p>{result.summary}</p>
          </div>
        </div>
      );
    }
    return <pre className="text-sm overflow-auto">{JSON.stringify(result, null, 2)}</pre>;
  };

  return (
    <div className="mt-8 p-6 lg:p-8 rounded-[2rem] border bg-indigo-50 dark:bg-indigo-900/10 border-indigo-200 dark:border-indigo-500/20 animate-in zoom-in-95 duration-300">
      <div className="flex justify-between items-center mb-6">
        <span className="text-xs font-black uppercase tracking-wider text-indigo-600 dark:text-indigo-400">AI Intelligence Result</span>
        <button onClick={onDiscard} className="text-slate-400 hover:text-slate-600 dark:hover:text-white transition-colors">
          <X size={20}/>
        </button>
      </div>
      
      <div className="mb-8">
        {renderContent()}
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <button 
          onClick={onAccept}
          className="flex-1 py-4 bg-indigo-600 hover:bg-indigo-700 text-white font-black rounded-2xl shadow-lg shadow-indigo-600/20 transition-all flex items-center justify-center gap-2"
        >
          <Check size={20} />
          {mode === 'planner' ? 'Save Tasks' : 'Save Note'}
        </button>
        <button 
          onClick={onDiscard}
          className="px-8 py-4 rounded-2xl font-bold border border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all"
        >
          Discard
        </button>
      </div>
    </div>
  );
}
