import React, { useState } from "react";
import { useApp } from "../state/AppContext";
import { CheckCircle2, Circle, Calendar, Edit2, Check, X } from "lucide-react";
import { Task } from "../state/types";

export default function TaskList() {
  const { state, dispatch } = useApp();
  const [editingTaskId, setEditingTaskId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState("");
  const [editPriority, setEditPriority] = useState<"low" | "medium" | "high">("medium");
  const [editDueDate, setEditDueDate] = useState("");

  const activeTasks = state.tasks
    .filter(t => !t.completed && (!state.activeProjectId || t.projectId === state.activeProjectId))
    .slice(0, 10);

  const startEditing = (task: Task) => {
    setEditingTaskId(task.id);
    setEditTitle(task.title);
    setEditPriority(task.priority || "medium");
    setEditDueDate(task.dueDate || "");
  };

  const saveEdit = (task: Task) => {
    dispatch({
      type: "UPDATE_TASK",
      payload: {
        ...task,
        title: editTitle,
        priority: editPriority,
        dueDate: editDueDate
      }
    });
    setEditingTaskId(null);
  };

  const syncToCalendar = (task: Task) => {
    if (!task.dueDate) return;
    const dateStr = task.dueDate.replace(/-/g, '');
    const url = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(task.title)}&dates=${dateStr}T000000Z/${dateStr}T235959Z`;
    window.open(url, '_blank');
  };

  if (activeTasks.length === 0) {
    return (
      <div className="p-8 text-center border border-dashed border-slate-300 dark:border-slate-800 rounded-3xl text-slate-500">
        No active tasks. Capture some thoughts to get started!
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {activeTasks.map((t) => (
        <div 
          key={t.id} 
          className="group p-6 rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm hover:shadow-md transition-all flex flex-col gap-4 relative overflow-hidden"
        >
          {editingTaskId === t.id ? (
            <div className="flex flex-col gap-3 w-full h-full">
              <input 
                type="text" 
                value={editTitle} 
                onChange={e => setEditTitle(e.target.value)} 
                className="w-full bg-transparent border-b border-slate-300 dark:border-slate-700 outline-none focus:border-[#4A90E2] pb-1 font-bold text-lg"
                autoFocus
              />
              <div className="flex flex-col gap-3 mt-auto">
                <select 
                  value={editPriority} 
                  onChange={e => setEditPriority(e.target.value as any)}
                  className="text-xs bg-slate-100 dark:bg-slate-800 rounded px-2 py-2 outline-none w-full"
                >
                  <option value="low">Low Priority</option>
                  <option value="medium">Medium Priority</option>
                  <option value="high">High Priority</option>
                </select>
                <input 
                  type="date" 
                  value={editDueDate} 
                  onChange={e => setEditDueDate(e.target.value)}
                  className="text-xs bg-slate-100 dark:bg-slate-800 rounded px-2 py-2 outline-none w-full"
                />
                <div className="flex items-center justify-end gap-2 mt-2">
                  <button onClick={() => setEditingTaskId(null)} className="p-2 text-slate-400 hover:text-rose-500 bg-slate-100 dark:bg-slate-800 rounded-lg"><X size={16}/></button>
                  <button onClick={() => saveEdit(t)} className="p-2 text-white bg-[#8BC34A] hover:bg-green-600 rounded-lg"><Check size={16}/></button>
                </div>
              </div>
            </div>
          ) : (
            <>
              <div className="flex justify-between items-start gap-4">
                <div 
                  className="flex-1 cursor-text" 
                  onClick={() => startEditing(t)}
                  title="Click to edit"
                >
                  <h3 className={`font-bold text-lg leading-tight mb-2 ${t.completed ? 'line-through text-slate-400' : 'text-slate-800 dark:text-slate-100'}`}>
                    {t.title}
                  </h3>
                  {t.dueDate && (
                    <span className="text-xs text-slate-500 flex items-center gap-1 font-medium">
                      <Calendar size={12} /> Due: {t.dueDate}
                    </span>
                  )}
                </div>
                <button 
                  className="text-slate-300 hover:text-[#8BC34A] transition-colors shrink-0 mt-1"
                  onClick={() => dispatch({ type: 'TOGGLE_TASK', payload: t.id })}
                >
                  {t.completed ? <CheckCircle2 className="text-[#8BC34A]" size={24} /> : <Circle size={24} />}
                </button>
              </div>
              
              <div className="mt-auto pt-4 flex items-center justify-between border-t border-slate-100 dark:border-slate-800/50">
                {t.priority && (
                  <span className={`text-[10px] font-black uppercase tracking-wider px-2.5 py-1 rounded-md ${
                    t.priority === 'high' ? 'bg-rose-100 text-rose-600 dark:bg-rose-500/10 dark:text-rose-500' :
                    t.priority === 'medium' ? 'bg-amber-100 text-amber-600 dark:bg-amber-500/10 dark:text-amber-500' :
                    'bg-green-100 text-[#8BC34A] dark:bg-green-500/10 dark:text-[#8BC34A]'
                  }`}>
                    {t.priority}
                  </span>
                )}
                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button 
                    onClick={() => startEditing(t)} 
                    className="p-1.5 text-slate-400 hover:text-[#4A90E2] transition-colors bg-slate-50 dark:bg-slate-800 rounded-md"
                    title="Edit Task"
                  >
                    <Edit2 size={14} />
                  </button>
                  {t.dueDate && (
                    <button 
                      onClick={() => syncToCalendar(t)} 
                      className="p-1.5 text-slate-400 hover:text-[#4A90E2] transition-colors bg-slate-50 dark:bg-slate-800 rounded-md"
                      title="Add to Google Calendar"
                    >
                      <Calendar size={14} />
                    </button>
                  )}
                </div>
              </div>
            </>
          )}
        </div>
      ))}
    </div>
  );
}
