import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Eye } from 'lucide-react';

export default function Auth() {
  const [isLogin, setIsLogin] = useState(true);
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    navigate('/app');
  };

  return (
    <div className="min-h-screen bg-[#1A1325] flex items-center justify-center p-4 relative overflow-hidden text-white font-sans">
      {/* Background Gradients */}
      <div className="absolute top-0 right-0 w-full h-full bg-[radial-gradient(circle_at_top_right,rgba(162,89,255,0.15),transparent_40%)] pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 w-full h-full bg-[radial-gradient(circle_at_bottom_left,rgba(0,224,150,0.1),transparent_40%)] pointer-events-none"></div>

      <div className="bg-[#261C35]/70 backdrop-blur-xl p-10 rounded-3xl border border-white/5 shadow-[0_20px_40px_rgba(0,0,0,0.4)] w-full max-w-[420px] relative z-10 overflow-hidden">
        <div className="text-2xl font-bold text-[#A259FF] mb-8 text-center tracking-wide">LifeOS AI</div>

        <div className="relative">
          {/* Login Form */}
          <div className={`transition-all duration-500 transform ${isLogin ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-full absolute top-0 left-0 w-full pointer-events-none'}`}>
            <div className="mb-8">
              <h2 className="text-3xl font-bold mb-2">Hey, Welcome Back</h2>
              <p className="text-[#A098AE] text-sm leading-relaxed">Seamless Access. Log in to your unified workspace.</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="relative">
                <input 
                  type="email" 
                  placeholder="Email Address" 
                  required 
                  className="w-full p-4 rounded-xl bg-[#2D233C] text-white border border-transparent focus:border-[#A259FF] focus:bg-[#2D233C]/90 outline-none transition-all placeholder:text-[#665b7a]"
                />
              </div>
              <div className="relative">
                <input 
                  type="password" 
                  placeholder="Password" 
                  required 
                  className="w-full p-4 rounded-xl bg-[#2D233C] text-white border border-transparent focus:border-[#A259FF] focus:bg-[#2D233C]/90 outline-none transition-all placeholder:text-[#665b7a]"
                />
                <button type="button" className="absolute right-4 top-1/2 -translate-y-1/2 text-[#A098AE] hover:text-white transition-colors">
                  <Eye size={20} />
                </button>
              </div>

              <div className="flex justify-between items-center text-sm py-2">
                <label className="flex items-center gap-2 text-[#A098AE] cursor-pointer">
                  <input type="checkbox" defaultChecked className="rounded border-gray-600 bg-[#2D233C] text-[#A259FF] focus:ring-[#A259FF]" />
                  Remember Me
                </label>
                <a href="#" className="text-[#A259FF] font-semibold hover:underline">Forget Password?</a>
              </div>

              <button type="submit" className="w-full bg-gradient-to-br from-[#A259FF] to-[#7A3FE4] text-white p-4 rounded-xl font-bold text-lg hover:opacity-90 hover:-translate-y-0.5 transition-all shadow-[0_4px_15px_rgba(162,89,255,0.3)] hover:shadow-[0_6px_20px_rgba(162,89,255,0.4)]">
                Log in
              </button>
            </form>

            <div className="flex items-center my-6 text-[#665b7a] text-sm uppercase tracking-wide">
              <div className="flex-1 border-b border-[#3A2E4D]"></div>
              <span className="px-4">Or continue with</span>
              <div className="flex-1 border-b border-[#3A2E4D]"></div>
            </div>

            <div className="space-y-3">
              <button className="w-full bg-transparent border border-[#3A2E4D] text-white p-3 rounded-xl font-semibold flex items-center justify-center gap-3 hover:bg-white/5 transition-colors">
                <span className="text-xl">🍎</span> Continue with Apple
              </button>
              <button className="w-full bg-transparent border border-[#3A2E4D] text-white p-3 rounded-xl font-semibold flex items-center justify-center gap-3 hover:bg-white/5 transition-colors">
                <span className="text-xl">🔵</span> Continue with Google
              </button>
            </div>

            <div className="text-center mt-6 text-3xl cursor-pointer text-[#A098AE] hover:text-[#A259FF] transition-colors" title="Set Your Fingerprint">
              👆
            </div>

            <p className="text-center mt-6 text-[#A098AE] text-sm">
              Don't have an Account? <button onClick={() => setIsLogin(false)} className="text-[#A259FF] font-bold hover:underline">Sign up</button>
            </p>
          </div>

          {/* Sign Up Form */}
          <div className={`transition-all duration-500 transform ${!isLogin ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-full absolute top-0 left-0 w-full pointer-events-none'}`}>
            <div className="mb-8">
              <h2 className="text-3xl font-bold mb-2">Let's get Started</h2>
              <p className="text-[#A098AE] text-sm leading-relaxed">Unleash the creator inside YOU. Join LifeOS AI.</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="flex gap-3">
                <div className="relative flex-1">
                  <input 
                    type="text" 
                    placeholder="First Name" 
                    required 
                    className="w-full p-4 rounded-xl bg-[#2D233C] text-white border border-transparent focus:border-[#A259FF] focus:bg-[#2D233C]/90 outline-none transition-all placeholder:text-[#665b7a]"
                  />
                </div>
                <div className="relative flex-1">
                  <input 
                    type="text" 
                    placeholder="Last Name" 
                    required 
                    className="w-full p-4 rounded-xl bg-[#2D233C] text-white border border-transparent focus:border-[#A259FF] focus:bg-[#2D233C]/90 outline-none transition-all placeholder:text-[#665b7a]"
                  />
                </div>
              </div>
              <div className="relative">
                <input 
                  type="email" 
                  placeholder="Email Address" 
                  required 
                  className="w-full p-4 rounded-xl bg-[#2D233C] text-white border border-transparent focus:border-[#A259FF] focus:bg-[#2D233C]/90 outline-none transition-all placeholder:text-[#665b7a]"
                />
              </div>
              <div className="relative">
                <input 
                  type="password" 
                  placeholder="Create Password" 
                  required 
                  className="w-full p-4 rounded-xl bg-[#2D233C] text-white border border-transparent focus:border-[#A259FF] focus:bg-[#2D233C]/90 outline-none transition-all placeholder:text-[#665b7a]"
                />
                <button type="button" className="absolute right-4 top-1/2 -translate-y-1/2 text-[#A098AE] hover:text-white transition-colors">
                  <Eye size={20} />
                </button>
              </div>

              <button type="submit" className="w-full bg-gradient-to-br from-[#A259FF] to-[#7A3FE4] text-white p-4 rounded-xl font-bold text-lg hover:opacity-90 hover:-translate-y-0.5 transition-all shadow-[0_4px_15px_rgba(162,89,255,0.3)] hover:shadow-[0_6px_20px_rgba(162,89,255,0.4)] mt-2">
                Create Account
              </button>
            </form>

            <div className="flex items-center my-6 text-[#665b7a] text-sm uppercase tracking-wide">
              <div className="flex-1 border-b border-[#3A2E4D]"></div>
              <span className="px-4">Or sign up with</span>
              <div className="flex-1 border-b border-[#3A2E4D]"></div>
            </div>

            <div className="space-y-3">
              <button className="w-full bg-transparent border border-[#3A2E4D] text-white p-3 rounded-xl font-semibold flex items-center justify-center gap-3 hover:bg-white/5 transition-colors">
                <span className="text-xl">🍎</span> Continue with Apple
              </button>
              <button className="w-full bg-transparent border border-[#3A2E4D] text-white p-3 rounded-xl font-semibold flex items-center justify-center gap-3 hover:bg-white/5 transition-colors">
                <span className="text-xl">🔵</span> Continue with Google
              </button>
            </div>

            <p className="text-center mt-6 text-[#A098AE] text-sm">
              Already A Member? <button onClick={() => setIsLogin(true)} className="text-[#A259FF] font-bold hover:underline">Log in</button>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
