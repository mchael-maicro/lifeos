import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useApp } from "../state/AppContext";
import { Check, Sparkles, ArrowLeft, Building2, Users, Zap } from "lucide-react";

export default function Pricing() {
  const navigate = useNavigate();
  const { state, dispatch } = useApp();
  const [isAnnual, setIsAnnual] = useState(false);

  const handleUpgrade = (tier: 'free' | 'pro' | 'team' | 'enterprise') => {
    dispatch({ type: 'UPGRADE_TIER', payload: tier });
    navigate('/app');
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-6 py-12 lg:py-24">
        
        <button 
          onClick={() => navigate('/app')}
          className="flex items-center gap-2 text-slate-500 hover:text-indigo-600 transition-colors mb-12 font-medium"
        >
          <ArrowLeft size={20} /> Back to Dashboard
        </button>

        <div className="text-center max-w-3xl mx-auto mb-16">
          <h1 className="text-4xl lg:text-6xl font-black tracking-tight mb-6">
            Simple, transparent pricing
          </h1>
          <p className="text-lg text-slate-500 dark:text-slate-400">
            Choose the perfect plan for your productivity needs. Upgrade anytime as you grow.
          </p>
          
          <div className="mt-10 flex items-center justify-center gap-4">
            <span className={`font-medium ${!isAnnual ? 'text-slate-900 dark:text-white' : 'text-slate-500'}`}>Monthly</span>
            <button 
              onClick={() => setIsAnnual(!isAnnual)}
              className="w-14 h-8 bg-indigo-600 rounded-full relative transition-colors"
            >
              <div className={`w-6 h-6 bg-white rounded-full absolute top-1 transition-transform ${isAnnual ? 'translate-x-7' : 'translate-x-1'}`} />
            </button>
            <span className={`font-medium flex items-center gap-2 ${isAnnual ? 'text-slate-900 dark:text-white' : 'text-slate-500'}`}>
              Annually <span className="text-[10px] uppercase font-bold bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full">Save 15%</span>
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Free Tier */}
          <div className="p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col">
            <div className="mb-8">
              <h3 className="text-xl font-bold mb-2">Free</h3>
              <p className="text-slate-500 text-sm h-10">Perfect for getting started with basic organization.</p>
              <div className="mt-6 flex items-baseline gap-1">
                <span className="text-4xl font-black">$0</span>
                <span className="text-slate-500">/mo</span>
              </div>
            </div>
            <ul className="space-y-4 mb-8 flex-1">
              {['5 AI tasks per day', 'Basic task management', 'Due date tracking', 'Priority setting', 'Email support'].map((feature, i) => (
                <li key={i} className="flex items-start gap-3 text-sm font-medium">
                  <Check size={18} className="text-emerald-500 shrink-0" />
                  <span>{feature}</span>
                </li>
              ))}
            </ul>
            <button 
              onClick={() => handleUpgrade('free')}
              className={`w-full py-3 rounded-xl font-bold transition-all ${state.user.tier === 'free' ? 'bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-default' : 'bg-indigo-50 text-indigo-600 hover:bg-indigo-100'}`}
            >
              {state.user.tier === 'free' ? 'Current Plan' : 'Downgrade'}
            </button>
          </div>

          {/* Pro Tier */}
          <div className="p-8 rounded-3xl bg-indigo-600 text-white shadow-2xl shadow-indigo-600/20 relative flex flex-col transform lg:-translate-y-4">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-gradient-to-r from-amber-400 to-orange-500 text-white text-xs font-black uppercase tracking-wider py-1 px-4 rounded-full flex items-center gap-1">
              <Sparkles size={12} /> Most Popular
            </div>
            <div className="mb-8">
              <h3 className="text-xl font-bold mb-2">Pro</h3>
              <p className="text-indigo-200 text-sm h-10">For individuals who need advanced AI and integrations.</p>
              <div className="mt-6 flex items-baseline gap-1">
                <span className="text-4xl font-black">${isAnnual ? '6.25' : '8'}</span>
                <span className="text-indigo-200">/mo</span>
              </div>
              {isAnnual && <p className="text-xs text-indigo-200 mt-1">Billed $75 yearly</p>}
            </div>
            <ul className="space-y-4 mb-8 flex-1">
              {['Unlimited AI tasks', 'Advanced AI prioritization', 'Google Calendar Sync', '1 Workspace', '100MB file storage', 'Priority email support'].map((feature, i) => (
                <li key={i} className="flex items-start gap-3 text-sm font-medium">
                  <Check size={18} className="text-indigo-300 shrink-0" />
                  <span>{feature}</span>
                </li>
              ))}
            </ul>
            <button 
              onClick={() => handleUpgrade('pro')}
              className={`w-full py-3 rounded-xl font-bold transition-all ${state.user.tier === 'pro' ? 'bg-indigo-800 text-indigo-300 cursor-default' : 'bg-white text-indigo-600 hover:scale-[1.02] shadow-lg'}`}
            >
              {state.user.tier === 'pro' ? 'Current Plan' : 'Upgrade to Pro'}
            </button>
          </div>

          {/* Team Tier */}
          <div className="p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col">
            <div className="mb-8">
              <h3 className="text-xl font-bold mb-2 flex items-center gap-2"><Users size={20} className="text-indigo-500"/> Team</h3>
              <p className="text-slate-500 text-sm h-10">For small teams needing collaboration and reporting.</p>
              <div className="mt-6 flex items-baseline gap-1">
                <span className="text-4xl font-black">${isAnnual ? '20.83' : '25'}</span>
                <span className="text-slate-500">/user/mo</span>
              </div>
              {isAnnual && <p className="text-xs text-slate-500 mt-1">Billed $250 yearly per user</p>}
            </div>
            <ul className="space-y-4 mb-8 flex-1">
              {['Everything in Pro', 'Multiple workspaces', 'Task-based permissions', 'Shared task boards', 'Team analytics', '2GB file storage'].map((feature, i) => (
                <li key={i} className="flex items-start gap-3 text-sm font-medium">
                  <Check size={18} className="text-emerald-500 shrink-0" />
                  <span>{feature}</span>
                </li>
              ))}
            </ul>
            <button 
              onClick={() => handleUpgrade('team')}
              className={`w-full py-3 rounded-xl font-bold transition-all ${state.user.tier === 'team' ? 'bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-default' : 'bg-indigo-50 text-indigo-600 hover:bg-indigo-100'}`}
            >
              {state.user.tier === 'team' ? 'Current Plan' : 'Upgrade to Team'}
            </button>
          </div>

          {/* Enterprise Tier */}
          <div className="p-8 rounded-3xl bg-slate-900 text-white border border-slate-800 flex flex-col">
            <div className="mb-8">
              <h3 className="text-xl font-bold mb-2 flex items-center gap-2"><Building2 size={20} className="text-indigo-400"/> Enterprise</h3>
              <p className="text-slate-400 text-sm h-10">For large organizations with complex workflows.</p>
              <div className="mt-6 flex items-baseline gap-1">
                <span className="text-4xl font-black">Custom</span>
              </div>
            </div>
            <ul className="space-y-4 mb-8 flex-1">
              {['Everything in Team', 'Dedicated account manager', 'Custom CRM/ERP integrations', 'SOC 2 Compliance', 'Single sign-on (SSO)', 'Unlimited storage'].map((feature, i) => (
                <li key={i} className="flex items-start gap-3 text-sm font-medium">
                  <Check size={18} className="text-indigo-400 shrink-0" />
                  <span>{feature}</span>
                </li>
              ))}
            </ul>
            <button 
              onClick={() => handleUpgrade('enterprise')}
              className={`w-full py-3 rounded-xl font-bold transition-all ${state.user.tier === 'enterprise' ? 'bg-slate-800 text-slate-500 cursor-default' : 'bg-white text-slate-900 hover:bg-slate-100'}`}
            >
              {state.user.tier === 'enterprise' ? 'Current Plan' : 'Contact Sales'}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
