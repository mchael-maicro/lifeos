import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Sparkles, ArrowRight } from "lucide-react";
import { runAI } from "../services/aiService";
import { useApp } from "../state/AppContext";

export default function Landing() {
  const navigate = useNavigate();
  const [input, setInput] = useState("");
  const [isThinking, setIsThinking] = useState(false);
  const { dispatch } = useApp();

  const handleTryIt = async () => {
    if (!input.trim()) return;
    setIsThinking(true);
    try {
      const result = await runAI("planner", input);
      if (result && result.tasks) {
        const tasks = result.tasks.map((t: any) => ({
          id: crypto.randomUUID(),
          title: t.title,
          completed: false,
          priority: t.priority || 'medium',
          createdAt: Date.now()
        }));
        dispatch({ type: "ADD_TASKS", payload: tasks });
        dispatch({ type: "INCREMENT_USAGE" });
        navigate("/app");
      }
    } catch (e) {
      console.error(e);
      navigate("/app");
    }
    setIsThinking(false);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white">
      <header className="w-full max-w-7xl mx-auto p-6 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-indigo-600 rounded-lg text-white">
            <Sparkles size={20} />
          </div>
          <span className="text-lg font-black tracking-tight">LifeOS.</span>
        </div>
        <div className="flex items-center gap-6">
          <button onClick={() => navigate('/pricing')} className="text-sm font-medium text-slate-500 hover:text-slate-900 dark:hover:text-white transition-colors">Pricing</button>
          <button onClick={() => navigate('/auth')} className="text-sm font-bold text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 transition-colors">Sign In</button>
        </div>
      </header>

      <div className="flex-1 flex flex-col items-center justify-center p-6">
        <div className="max-w-2xl w-full space-y-12 text-center">
          <div className="flex justify-center mb-8">
            <div className="p-3 bg-indigo-600 rounded-2xl text-white shadow-xl shadow-indigo-600/30">
              <Sparkles size={32} />
            </div>
          </div>
        
        <h1 className="text-5xl md:text-7xl font-black tracking-tight leading-tight">
          Turn messy thoughts into <span className="text-indigo-600 dark:text-indigo-400">clear actions.</span>
        </h1>
        
        <p className="text-xl text-slate-500 dark:text-slate-400 max-w-xl mx-auto">
          LifeOS AI is your intelligent thinking partner. Dump your chaos, get a structured plan.
        </p>

        <div className="bg-white dark:bg-slate-900 p-2 rounded-[2rem] shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row gap-2 max-w-xl mx-auto">
          <input
            type="text"
            placeholder="What’s on your mind right now?"
            className="flex-1 bg-transparent px-6 py-4 outline-none text-lg"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleTryIt()}
          />
          <button
            onClick={() => navigate('/auth')}
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-4 rounded-[1.5rem] font-bold transition-all flex items-center justify-center gap-2"
          >
            Get Started
            <ArrowRight size={20} />
          </button>
        </div>
        
        <p className="text-sm text-slate-400">No credit card required. Start building clarity instantly.</p>
      </div>
      </div>
    </div>
  );
}
