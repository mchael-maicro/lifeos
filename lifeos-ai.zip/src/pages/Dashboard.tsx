import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import CaptureInput from "../components/CaptureInput";
import AIModeSelector from "../components/AIModeSelector";
import AIResultPanel from "../components/AIResultPanel";
import TaskList from "../components/TaskList";
import ActionButton from "../components/ActionButton";
import Sidebar from "../components/Sidebar";
import { TeamView, CRMView, EcommerceView, ChatView, TravelView, CryptoView, CalendarView, IntegrationsView, StudioView, AIStudioView } from "../components/ProViews";
import { useApp } from "../state/AppContext";
import { Sparkles, Sun, Moon, ShieldCheck, AlertCircle, Target, FolderPlus, Zap, Clock, CheckCircle2, ListTodo, TrendingUp, Home, StickyNote, CheckSquare, Folder, Settings, Repeat, Timer, Check, LayoutDashboard, Workflow } from "lucide-react";

function HabitsView() {
  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-black tracking-tight mb-2">Habits & Routines</h1>
          <p className="text-slate-500 dark:text-slate-400 font-medium">Build consistency and track your daily goals.</p>
        </div>
        <ActionButton 
          className="px-4 py-2 bg-[#FF9800] text-white font-bold rounded-xl hover:bg-orange-600 transition-colors shadow-lg shadow-orange-500/20"
          successText="Habit Created!"
          loadingText="Creating..."
        >
          + New Habit
        </ActionButton>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-10">
        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800 border-b-4 border-b-[#4A90E2]">
          <h3 className="text-[#4A90E2] text-3xl font-black mb-1">14 Days</h3>
          <p className="text-slate-500 text-xs font-bold uppercase tracking-wider">Current Streak</p>
        </div>
        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800 border-b-4 border-b-[#8BC34A]">
          <h3 className="text-[#8BC34A] text-3xl font-black mb-1">85%</h3>
          <p className="text-slate-500 text-xs font-bold uppercase tracking-wider">Weekly Progress</p>
        </div>
      </div>

      <h3 className="text-xl font-black mb-6">Today's Routines</h3>
      <div className="space-y-4">
        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800 flex items-center justify-between hover:border-[#4A90E2]/50 transition-colors cursor-pointer group">
          <div>
            <h4 className="font-bold text-lg flex items-center gap-3 mb-1">
              <span className="text-2xl">🏃‍♂️</span> Sports every day
            </h4>
            <p className="text-sm text-slate-500 font-medium">🔥 12 Day Streak • Morning Routine</p>
          </div>
          <div className="w-8 h-8 rounded-full border-2 border-slate-300 dark:border-slate-700 group-hover:border-[#4A90E2] transition-colors"></div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800 flex items-center justify-between hover:border-[#4A90E2]/50 transition-colors cursor-pointer group">
          <div>
            <h4 className="font-bold text-lg flex items-center gap-3 mb-1 line-through text-slate-400">
              <span className="text-2xl opacity-50">📚</span> Read 2 books this month
            </h4>
            <p className="text-sm text-slate-500 font-medium">🔥 5 Day Streak • Evening Routine</p>
          </div>
          <div className="w-8 h-8 rounded-full bg-[#8BC34A] text-white flex items-center justify-center">
            <Check size={16} strokeWidth={3} />
          </div>
        </div>
      </div>
    </div>
  );
}

function FocusView() {
  const [isStrict, setIsStrict] = useState(true);
  
  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="mb-8">
        <h1 className="text-3xl font-black tracking-tight mb-2">Deep Focus</h1>
        <p className="text-slate-500 dark:text-slate-400 font-medium">Eliminate distractions and execute.</p>
      </div>

      <div className="bg-gradient-to-br from-white to-slate-50 dark:from-slate-900 dark:to-slate-950 p-10 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800 flex flex-col items-center justify-center mb-8">
        
        <div className="relative w-64 h-64 rounded-full border-[12px] border-slate-100 dark:border-slate-800 flex flex-col items-center justify-center mb-10 shadow-inner">
          <svg className="absolute inset-0 w-full h-full transform -rotate-90" viewBox="0 0 100 100">
            <circle cx="50" cy="50" r="44" fill="none" stroke="#4A90E2" strokeWidth="12" strokeDasharray="276" strokeDashoffset="60" strokeLinecap="round" />
          </svg>
          <h1 className="text-6xl font-black text-slate-800 dark:text-white tracking-tighter mb-1 relative z-10">25:00</h1>
          <p className="text-slate-400 font-bold uppercase tracking-[0.2em] text-sm relative z-10">Pomodoro</p>
        </div>

        <div className="flex items-center gap-4">
          <ActionButton 
            className="px-10 py-4 bg-[#4A90E2] hover:bg-blue-600 text-white font-black rounded-full transition-all shadow-lg shadow-blue-500/30 hover:scale-105 text-lg"
            successText="Focus Started!"
            loadingText="Starting..."
          >
            Start Focus
          </ActionButton>
          <ActionButton 
            className="px-8 py-4 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold rounded-full border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors text-lg"
            successText="Skipped!"
            loadingText="Skipping..."
          >
            Skip
          </ActionButton>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800 border-l-4 border-l-[#E74C3C] flex items-center justify-between">
        <div>
          <h3 className="font-bold text-lg mb-1">Strict Mode (Do Not Disturb)</h3>
          <p className="text-sm text-slate-500">Blocks notifications and silences AI chat sync while timer is active.</p>
        </div>
        <button 
          onClick={() => setIsStrict(!isStrict)}
          className={`w-14 h-8 rounded-full transition-colors relative ${isStrict ? 'bg-[#8BC34A]' : 'bg-slate-300 dark:bg-slate-700'}`}
        >
          <div className={`absolute top-1 w-6 h-6 rounded-full bg-white transition-all ${isStrict ? 'left-7' : 'left-1'}`} />
        </button>
      </div>
    </div>
  );
}

function SpacesView() {
  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-black tracking-tight mb-2">Smart Spaces</h1>
          <p className="text-slate-500 dark:text-slate-400 font-medium">Your modular, infinite canvas for complete project organization.</p>
        </div>
        <ActionButton 
          className="px-4 py-2 bg-[#4A90E2] text-white font-bold rounded-xl hover:bg-blue-600 transition-colors shadow-lg shadow-blue-500/20 whitespace-nowrap"
          successText="Space Created!"
          loadingText="Creating..."
        >
          + Create New Space
        </ActionButton>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
        <div className="bg-gradient-to-br from-slate-900 to-slate-800 p-6 rounded-3xl shadow-sm border border-[#4A90E2] flex flex-col">
          <h3 className="text-white text-xl font-black mb-2">🎬 YouTube Vlog Production</h3>
          <p className="text-slate-400 text-sm font-medium mb-6">Contains: 1 Script, 3 Tasks, 4 AI Generated Images, 1 Moodboard</p>
          <ActionButton 
            className="mt-auto w-full py-3 bg-[#4A90E2] text-white font-bold rounded-xl hover:bg-blue-600 transition-colors"
            successText="Entered!"
            loadingText="Loading..."
          >
            Enter Workspace
          </ActionButton>
        </div>
        <div className="bg-gradient-to-br from-slate-900 to-slate-800 p-6 rounded-3xl shadow-sm border border-[#8BC34A] flex flex-col">
          <h3 className="text-white text-xl font-black mb-2">🛍️ Q3 Marketing Campaign</h3>
          <p className="text-slate-400 text-sm font-medium mb-6">Contains: 12 Social Posts, 1 Financial Tracker, 2 Team Members</p>
          <ActionButton 
            className="mt-auto w-full py-3 bg-[#8BC34A] text-white font-bold rounded-xl hover:bg-green-600 transition-colors"
            successText="Entered!"
            loadingText="Loading..."
          >
            Enter Workspace
          </ActionButton>
        </div>
      </div>

      <h3 className="text-xl font-black mb-4">Suggested Modules to Drag & Drop</h3>
      <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
        <div className="shrink-0 px-6 py-3 bg-blue-100 dark:bg-blue-500/20 text-[#4A90E2] font-bold rounded-full cursor-pointer hover:bg-blue-200 dark:hover:bg-blue-500/30 transition-colors">📝 Text Editor</div>
        <div className="shrink-0 px-6 py-3 bg-amber-100 dark:bg-amber-500/20 text-amber-600 font-bold rounded-full cursor-pointer hover:bg-amber-200 dark:hover:bg-amber-500/30 transition-colors">✅ Kanban Board</div>
        <div className="shrink-0 px-6 py-3 bg-green-100 dark:bg-green-500/20 text-[#8BC34A] font-bold rounded-full cursor-pointer hover:bg-green-200 dark:hover:bg-green-500/30 transition-colors">📊 Finance Widget</div>
        <div className="shrink-0 px-6 py-3 bg-rose-100 dark:bg-rose-500/20 text-rose-600 font-bold rounded-full cursor-pointer hover:bg-rose-200 dark:hover:bg-rose-500/30 transition-colors">🤖 AI Prompt Box</div>
      </div>
    </div>
  );
}

function FlowsView() {
  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-black tracking-tight mb-2">Logic Flows</h1>
          <p className="text-slate-500 dark:text-slate-400 font-medium">Automate your life with visual, node-based programming.</p>
        </div>
        <ActionButton 
          className="px-4 py-2 bg-[#FF9800] text-white font-bold rounded-xl hover:bg-orange-600 transition-colors shadow-lg shadow-orange-500/20 whitespace-nowrap"
          successText="Ready!"
          loadingText="Building..."
        >
          + Build Automation
        </ActionButton>
      </div>

      <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800 border-l-4 border-l-[#FF9800] mb-10">
        <h3 className="text-xl font-black mb-6">Active Flow: "Morning Briefing"</h3>
        
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 bg-slate-50 dark:bg-slate-950 p-6 rounded-2xl">
          
          <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 text-center w-full md:w-40 shadow-sm">
            <span className="text-3xl block mb-2">⏰</span>
            <strong className="text-sm block">Every Day<br/>8:00 AM</strong>
          </div>

          <div className="text-[#FF9800] font-black text-2xl rotate-90 md:rotate-0">➔</div>

          <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-[#4A90E2] text-center w-full md:w-40 shadow-sm">
            <span className="text-3xl block mb-2">🤖</span>
            <strong className="text-sm text-[#4A90E2] block">AI Agent</strong>
            <span className="text-xs text-slate-500 mt-1 block">Summarize Schedule</span>
          </div>

          <div className="text-[#FF9800] font-black text-2xl rotate-90 md:rotate-0">➔</div>

          <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-[#25D366] text-center w-full md:w-40 shadow-sm">
            <span className="text-3xl block mb-2">💬</span>
            <strong className="text-sm text-[#25D366] block">WhatsApp</strong>
            <span className="text-xs text-slate-500 mt-1 block">Send Message</span>
          </div>

        </div>
      </div>

      <h3 className="text-xl font-black mb-4">Automation Templates</h3>
      <div className="space-y-4">
        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div>
            <h4 className="font-bold text-lg mb-1">📧 Email to Task (AI Sorted)</h4>
            <p className="text-sm text-slate-500 font-medium">When a VIP emails you ➔ AI extracts action items ➔ Creates tasks in To-Do list.</p>
          </div>
          <div className="w-12 h-6 rounded-full bg-slate-200 dark:bg-slate-700 relative cursor-pointer">
            <div className="absolute top-1 left-1 w-4 h-4 rounded-full bg-white transition-all"></div>
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div>
            <h4 className="font-bold text-lg mb-1">💰 Auto-Expense Tracker</h4>
            <p className="text-sm text-slate-500 font-medium">When a bank SMS arrives ➔ AI reads the amount ➔ Logs it in the Finance Dashboard.</p>
          </div>
          <div className="w-12 h-6 rounded-full bg-[#8BC34A] relative cursor-pointer">
            <div className="absolute top-1 left-7 w-4 h-4 rounded-full bg-white transition-all"></div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const navigate = useNavigate();
  const { state, dispatch } = useApp();
  const [mode, setMode] = useState("planner");
  const [result, setResult] = useState<any>(null);
  const [isThinking, setIsThinking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'tasks' | 'projects' | 'calendar' | 'habits' | 'focus' | 'finance' | 'crypto' | 'health' | 'elearning' | 'aistudio' | 'ai-chat' | 'studio' | 'spaces' | 'flows' | 'files' | 'team' | 'crm' | 'ecommerce' | 'chat' | 'travel' | 'integrations' | 'ai-suggestions' | 'applock' | 'settings'>('dashboard');
  const [isPlaying, setIsPlaying] = useState(true);

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const dueSoonTasks = state.tasks.filter(t => {
    if (t.completed || !t.dueDate) return false;
    const dueDate = new Date(t.dueDate);
    dueDate.setHours(0, 0, 0, 0);
    const diffTime = dueDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays <= 1;
  });

  const totalTasks = state.tasks.length;
  const completedTasks = state.tasks.filter(t => t.completed).length;
  const completionRate = totalTasks === 0 ? 0 : Math.round((completedTasks / totalTasks) * 100);

  const handleCapture = async (text: string) => {
    setError(null);
    
    if (state.user.tier === 'free' && state.usage.count >= 5) {
      setError("You've reached your daily AI limit. Upgrade to Pro for unlimited clarity.");
      return;
    }

    setIsThinking(true);
    try {
      const aiResult = await runAI(mode, text);
      if (aiResult) {
        setResult(aiResult);
        dispatch({ type: "INCREMENT_USAGE" });
      } else {
        setError("AI returned an empty response.");
      }
    } catch (e) {
      setError("Failed to process with AI. Please try again.");
    }
    setIsThinking(false);
  };

  const handleAcceptAI = () => {
    if (mode === 'planner' && result?.tasks) {
      const tasks = result.tasks.map((t: any) => ({
        id: crypto.randomUUID(),
        title: t.title,
        completed: false,
        priority: t.priority || 'medium',
        projectId: state.activeProjectId || undefined,
        createdAt: Date.now()
      }));
      dispatch({ type: "ADD_TASKS", payload: tasks });
    } else {
      console.log("Saved note:", result);
    }
    setResult(null);
  };

  return (
    <div className="min-h-screen bg-[#F7F7F7] dark:bg-slate-950 text-[#333333] dark:text-slate-100 font-sans pb-24 transition-colors duration-300 flex">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <div className="flex-1 lg:ml-72 flex flex-col min-h-screen relative">
        {/* Top Header */}
        <header className="max-w-5xl mx-auto w-full p-6 pt-8 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-[#4A90E2] text-white flex items-center justify-center font-bold text-xl shadow-lg shadow-blue-500/20">
            {state.user.id === 'user_1' ? 'M' : state.user.id.charAt(0).toUpperCase()}
          </div>
          <div>
            <h1 className="text-2xl font-black tracking-tight">Welcome back, Michael</h1>
            <p className="text-slate-500 dark:text-slate-400 text-sm">What's on your mind today?</p>
          </div>
        </div>
        <div className="flex-1 max-w-xl w-full flex items-center gap-4">
          <CaptureInput onSubmit={handleCapture} isThinking={isThinking} />
          <button 
            onClick={() => dispatch({ type: 'TOGGLE_THEME' })} 
            className="p-3 rounded-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-500 hover:text-[#4A90E2] transition-colors shrink-0"
          >
            {state.isDarkMode ? <Sun size={20}/> : <Moon size={20}/>}
          </button>
        </div>
      </header>

        <main className="max-w-5xl mx-auto w-full p-6 space-y-8 flex-1">
        {/* Tab Navigation (Mobile Only) */}
        <div className="flex lg:hidden space-x-2 bg-slate-200/50 dark:bg-slate-800/50 p-1.5 rounded-2xl mb-2 overflow-x-auto scrollbar-hide">
          <button 
            onClick={() => setActiveTab('dashboard')} 
            className={`shrink-0 px-4 py-2.5 rounded-xl font-bold text-sm transition-all ${activeTab === 'dashboard' ? 'bg-white dark:bg-slate-900 shadow-sm text-[#4A90E2]' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
          >
            Overview
          </button>
          <button 
            onClick={() => setActiveTab('spaces')} 
            className={`shrink-0 px-4 py-2.5 rounded-xl font-bold text-sm transition-all ${activeTab === 'spaces' ? 'bg-white dark:bg-slate-900 shadow-sm text-[#4A90E2]' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
          >
            Spaces
          </button>
          <button 
            onClick={() => setActiveTab('flows')} 
            className={`shrink-0 px-4 py-2.5 rounded-xl font-bold text-sm transition-all ${activeTab === 'flows' ? 'bg-white dark:bg-slate-900 shadow-sm text-[#4A90E2]' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
          >
            Flows
          </button>
          <button 
            onClick={() => setActiveTab('habits')} 
            className={`shrink-0 px-4 py-2.5 rounded-xl font-bold text-sm transition-all ${activeTab === 'habits' ? 'bg-white dark:bg-slate-900 shadow-sm text-[#4A90E2]' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
          >
            Habits
          </button>
          <button 
            onClick={() => setActiveTab('focus')} 
            className={`shrink-0 px-4 py-2.5 rounded-xl font-bold text-sm transition-all ${activeTab === 'focus' ? 'bg-white dark:bg-slate-900 shadow-sm text-[#4A90E2]' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
          >
            Focus
          </button>
          <button 
            onClick={() => setActiveTab('team')} 
            className={`shrink-0 px-4 py-2.5 rounded-xl font-bold text-sm transition-all ${activeTab === 'team' ? 'bg-white dark:bg-slate-900 shadow-sm text-[#4A90E2]' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
          >
            TeamHub
          </button>
          <button 
            onClick={() => setActiveTab('crm')} 
            className={`shrink-0 px-4 py-2.5 rounded-xl font-bold text-sm transition-all ${activeTab === 'crm' ? 'bg-white dark:bg-slate-900 shadow-sm text-[#4A90E2]' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
          >
            AIZCRM
          </button>
          <button 
            onClick={() => setActiveTab('ecommerce')} 
            className={`shrink-0 px-4 py-2.5 rounded-xl font-bold text-sm transition-all ${activeTab === 'ecommerce' ? 'bg-white dark:bg-slate-900 shadow-sm text-[#4A90E2]' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
          >
            E-Commerce
          </button>
          <button 
            onClick={() => setActiveTab('chat')} 
            className={`shrink-0 px-4 py-2.5 rounded-xl font-bold text-sm transition-all ${activeTab === 'chat' ? 'bg-white dark:bg-slate-900 shadow-sm text-[#4A90E2]' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
          >
            Messages
          </button>
          <button 
            onClick={() => setActiveTab('travel')} 
            className={`shrink-0 px-4 py-2.5 rounded-xl font-bold text-sm transition-all ${activeTab === 'travel' ? 'bg-white dark:bg-slate-900 shadow-sm text-[#4A90E2]' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
          >
            Travel
          </button>
          <button 
            onClick={() => setActiveTab('crypto')} 
            className={`shrink-0 px-4 py-2.5 rounded-xl font-bold text-sm transition-all ${activeTab === 'crypto' ? 'bg-white dark:bg-slate-900 shadow-sm text-[#4A90E2]' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
          >
            Crypto
          </button>
          <button 
            onClick={() => setActiveTab('calendar')} 
            className={`shrink-0 px-4 py-2.5 rounded-xl font-bold text-sm transition-all ${activeTab === 'calendar' ? 'bg-white dark:bg-slate-900 shadow-sm text-[#4A90E2]' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
          >
            Calendar
          </button>
          <button 
            onClick={() => setActiveTab('integrations')} 
            className={`shrink-0 px-4 py-2.5 rounded-xl font-bold text-sm transition-all ${activeTab === 'integrations' ? 'bg-white dark:bg-slate-900 shadow-sm text-[#4A90E2]' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
          >
            Integrations
          </button>
          <button 
            onClick={() => setActiveTab('studio')} 
            className={`shrink-0 px-4 py-2.5 rounded-xl font-bold text-sm transition-all ${activeTab === 'studio' ? 'bg-white dark:bg-slate-900 shadow-sm text-[#4A90E2]' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
          >
            Audio Studio
          </button>
          <button 
            onClick={() => setActiveTab('aistudio')} 
            className={`shrink-0 px-4 py-2.5 rounded-xl font-bold text-sm transition-all ${activeTab === 'aistudio' ? 'bg-white dark:bg-slate-900 shadow-sm text-[#4A90E2]' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
          >
            AI Studio
          </button>
        </div>

        {dueSoonTasks.length > 0 && activeTab === 'dashboard' && (
          <div className="p-5 rounded-2xl bg-orange-50 dark:bg-orange-500/10 border border-orange-200 dark:border-orange-500/20 text-orange-800 dark:text-orange-400 flex items-start gap-4 animate-in slide-in-from-top-2">
            <Clock size={24} className="shrink-0 mt-0.5 text-[#FF9800]" />
            <div>
              <h4 className="font-bold mb-2 text-[#FF9800]">Upcoming Deadlines</h4>
              <ul className="space-y-1.5 text-sm">
                {dueSoonTasks.map(t => (
                  <li key={t.id} className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#FF9800] shrink-0" />
                    <span className="font-medium">{t.title}</span>
                    <span className="opacity-75">({t.dueDate})</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}

        {error && (
          <div className="p-6 rounded-2xl bg-rose-50 dark:bg-rose-500/10 border border-rose-200 dark:border-rose-500/20 text-rose-600 dark:text-rose-400 flex flex-col sm:flex-row items-start sm:items-center gap-4 animate-in slide-in-from-top-2">
            <AlertCircle size={24} className="shrink-0" />
            <div className="flex-1">
              <p className="font-bold">{error}</p>
            </div>
            {state.user.tier === 'free' && (
              <button 
                onClick={() => navigate('/pricing')}
                className="px-6 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl text-sm transition-colors whitespace-nowrap"
              >
                Upgrade to Pro
              </button>
            )}
          </div>
        )}

        {result && (
          <AIResultPanel 
            result={result} 
            mode={mode} 
            onAccept={handleAcceptAI} 
            onDiscard={() => setResult(null)} 
          />
        )}

        {activeTab === 'dashboard' && (
          <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
            {/* Dynamic Life Stats */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              {/* Focus */}
              <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800 flex items-center gap-4">
                <div className="relative w-14 h-14 flex items-center justify-center">
                  <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                    <path className="text-slate-100 dark:text-slate-800" strokeWidth="3" stroke="currentColor" fill="none" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                    <path className="text-[#8BC34A]" strokeDasharray="75, 100" strokeWidth="3" strokeLinecap="round" stroke="currentColor" fill="none" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                  </svg>
                  <span className="absolute text-sm font-bold">75%</span>
                </div>
                <div>
                  <p className="text-sm text-slate-500 font-medium">Focus</p>
                  <p className="text-xl font-black">4 hrs logged</p>
                </div>
              </div>
              {/* Tasks */}
              <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800 flex items-center gap-4">
                <div className="relative w-14 h-14 flex items-center justify-center">
                  <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                    <path className="text-slate-100 dark:text-slate-800" strokeWidth="3" stroke="currentColor" fill="none" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                    <path className="text-[#4A90E2]" strokeDasharray={`${completionRate}, 100`} strokeWidth="3" strokeLinecap="round" stroke="currentColor" fill="none" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                  </svg>
                  <span className="absolute text-sm font-bold">{completedTasks}</span>
                </div>
                <div>
                  <p className="text-sm text-slate-500 font-medium">Tasks</p>
                  <p className="text-xl font-black">{completedTasks} done today</p>
                </div>
              </div>
              {/* Habits */}
              <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-800 flex items-center gap-4">
                <div className="relative w-14 h-14 flex items-center justify-center">
                  <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                    <path className="text-slate-100 dark:text-slate-800" strokeWidth="3" stroke="currentColor" fill="none" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                    <path className="text-[#FF9800]" strokeDasharray="75, 100" strokeWidth="3" strokeLinecap="round" stroke="currentColor" fill="none" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                  </svg>
                  <span className="absolute text-sm font-bold">3/4</span>
                </div>
                <div>
                  <p className="text-sm text-slate-500 font-medium">Habits</p>
                  <p className="text-xl font-black">Daily goals hit</p>
                </div>
              </div>
            </div>

            {/* Actionable Task Cards */}
            <div>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-black">Actionable Priorities</h2>
                <AIModeSelector mode={mode} setMode={setMode} />
              </div>
              <TaskList />
            </div>
          </div>
        )}

        {activeTab === 'habits' && <HabitsView />}
        {activeTab === 'focus' && <FocusView />}
        {activeTab === 'spaces' && <SpacesView />}
        {activeTab === 'flows' && <FlowsView />}
        {activeTab === 'team' && <TeamView />}
        {activeTab === 'crm' && <CRMView />}
        {activeTab === 'ecommerce' && <EcommerceView />}
        {activeTab === 'chat' && <ChatView />}
        {activeTab === 'travel' && <TravelView />}
        {activeTab === 'crypto' && <CryptoView />}
        {activeTab === 'calendar' && <CalendarView />}
        {activeTab === 'integrations' && <IntegrationsView />}
        {activeTab === 'studio' && <StudioView />}
        {activeTab === 'aistudio' && <AIStudioView />}
        
        {/* Placeholders for new tabs */}
        {['tasks', 'projects', 'finance', 'health', 'elearning', 'ai-chat', 'files', 'ai-suggestions', 'applock', 'settings'].includes(activeTab) && (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 flex flex-col items-center justify-center py-20 text-center">
            <div className="w-24 h-24 bg-slate-200 dark:bg-slate-800 rounded-full flex items-center justify-center text-4xl mb-6">
              🚧
            </div>
            <h2 className="text-2xl font-black mb-2">Coming Soon</h2>
            <p className="text-slate-500 font-medium max-w-md">This module is currently under construction. Check back later for updates!</p>
          </div>
        )}
      </main>

      {/* Floating Music Player */}
      <div className="fixed bottom-[80px] left-1/2 -translate-x-1/2 lg:translate-x-[calc(-50%+144px)] bg-slate-900/85 backdrop-blur-md border border-[#4A90E2] px-6 py-3 rounded-full flex items-center gap-4 shadow-2xl shadow-black/50 z-[9000] text-white whitespace-nowrap">
        <div className={`w-8 h-8 rounded-full bg-[#4A90E2] flex justify-center items-center text-sm ${isPlaying ? 'animate-[spin_4s_linear_infinite]' : ''}`}>🎵</div>
        <div className="flex flex-col">
          <span className="text-sm font-bold">Deep Focus House Mix</span>
          <span className="text-[10px] text-slate-400">Studio Pley • {isPlaying ? 'Playing' : 'Paused'}</span>
        </div>
        <div className="flex gap-3 ml-2">
          <button className="hover:scale-110 hover:text-[#4A90E2] transition-transform">⏮</button>
          <button onClick={() => setIsPlaying(!isPlaying)} className="hover:scale-110 hover:text-[#4A90E2] transition-transform w-4">{isPlaying ? '⏸' : '▶'}</button>
          <button className="hover:scale-110 hover:text-[#4A90E2] transition-transform">⏭</button>
        </div>
      </div>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 w-full bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 pb-safe z-50 lg:hidden">
        <div className="max-w-md mx-auto flex justify-between items-center px-6 py-3">
          <button onClick={() => setActiveTab('dashboard')} className={`flex flex-col items-center gap-1 transition-colors ${activeTab === 'dashboard' ? 'text-[#4A90E2]' : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'}`}>
            <Home size={24} className={activeTab === 'dashboard' ? "drop-shadow-[0_0_8px_rgba(74,144,226,0.5)]" : ""} />
            <span className={`text-[10px] ${activeTab === 'dashboard' ? 'font-bold' : 'font-medium'}`}>Home</span>
          </button>
          <button onClick={() => setActiveTab('spaces')} className={`flex flex-col items-center gap-1 transition-colors ${activeTab === 'spaces' ? 'text-[#4A90E2]' : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'}`}>
            <LayoutDashboard size={24} className={activeTab === 'spaces' ? "drop-shadow-[0_0_8px_rgba(74,144,226,0.5)]" : ""} />
            <span className={`text-[10px] ${activeTab === 'spaces' ? 'font-bold' : 'font-medium'}`}>Spaces</span>
          </button>
          <button onClick={() => setActiveTab('flows')} className={`flex flex-col items-center gap-1 transition-colors ${activeTab === 'flows' ? 'text-[#4A90E2]' : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'}`}>
            <Workflow size={24} className={activeTab === 'flows' ? "drop-shadow-[0_0_8px_rgba(74,144,226,0.5)]" : ""} />
            <span className={`text-[10px] ${activeTab === 'flows' ? 'font-bold' : 'font-medium'}`}>Flows</span>
          </button>
          <button onClick={() => setActiveTab('habits')} className={`flex flex-col items-center gap-1 transition-colors ${activeTab === 'habits' ? 'text-[#4A90E2]' : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'}`}>
            <Repeat size={24} className={activeTab === 'habits' ? "drop-shadow-[0_0_8px_rgba(74,144,226,0.5)]" : ""} />
            <span className={`text-[10px] ${activeTab === 'habits' ? 'font-bold' : 'font-medium'}`}>Habits</span>
          </button>
          <button onClick={() => setActiveTab('focus')} className={`flex flex-col items-center gap-1 transition-colors ${activeTab === 'focus' ? 'text-[#4A90E2]' : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'}`}>
            <Timer size={24} className={activeTab === 'focus' ? "drop-shadow-[0_0_8px_rgba(74,144,226,0.5)]" : ""} />
            <span className={`text-[10px] ${activeTab === 'focus' ? 'font-bold' : 'font-medium'}`}>Focus</span>
          </button>
        </div>
      </nav>
      </div>
    </div>
  );
}
